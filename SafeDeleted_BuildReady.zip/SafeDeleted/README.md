# SafeDeleted (independent implementation)

A minimal, locally encrypted Android notification archive for WhatsApp and WhatsApp Business. Written independently; **no original WhatsDeleted source code or binaries are included**.

## Build
Open this folder in Android Studio with Android SDK 35 installed and build the `app` module. Gradle/Android dependencies must be downloaded from official repositories during build. No prebuilt APK is included and the project has not been compiled or tested in this environment.

## Security design
- No `INTERNET` permission and no network libraries, analytics, ads, or third-party services.
- Android Keystore AES-256-GCM encryption at rest; application data excluded from Android backup.
- Ignores notifications from packages other than `com.whatsapp` and `com.whatsapp.w4b`.
- Retains the latest 1,000 captured notification entries; manual delete option.
- No access to WhatsApp databases, chats, contacts, media storage, or device files.

## Important limitations
- Notification listener access is powerful: Android grants access to notifications from *all* apps, even though this implementation filters by package. Review the code before enabling it.
- It cannot retrieve messages deleted before installation, messages never displayed in notifications, or reliably distinguish deleted from nondeleted messages. It archives notification text rather than detecting deletion.
- Message previews, grouped notifications, edits, and notification updates can cause incomplete or duplicate entries. Media is not saved.
- Local encryption does not protect against a compromised/unlocked device, malware with elevated privileges, or screenshots while the app is open.
- The app does not include a biometric lock. Consider device screen-lock protection.
- If a notification contains sensitive information, this app will store it until deleted.
- This is an initial source project, not a security-audited production app.
