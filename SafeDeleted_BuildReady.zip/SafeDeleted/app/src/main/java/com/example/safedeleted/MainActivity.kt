package com.example.safedeleted

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
 override fun onResume() { super.onResume(); render() }
 private fun render() {
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 16) }
  val heading = TextView(this).apply { text = "SafeDeleted — local WhatsApp notification archive"; textSize = 21f }
  root.addView(heading)
  root.addView(TextView(this).apply { text = "Only WhatsApp notification text is saved. No internet permission. Other apps' notifications are ignored. Notification access itself is system-wide, so only enable it if you trust this app."; setPadding(0, 12, 0, 12) })
  root.addView(Button(this).apply { text = "Manage notification access"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
  root.addView(Button(this).apply { text = "Delete all saved messages"; setOnClickListener { SecureStore.clear(this@MainActivity); getSharedPreferences("dedupe", MODE_PRIVATE).edit().clear().apply(); render() } })
  val scroll = ScrollView(this)
  val entries = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
  val data = SecureStore.read(this)
  for (i in data.length() - 1 downTo 0) {
   val item = data.optJSONObject(i) ?: continue
   val time = DateFormat.getDateTimeInstance().format(Date(item.optLong("time")))
   entries.addView(TextView(this).apply { text = "${item.optString("sender")} • $time\n${item.optString("message")}"; textSize = 16f; setPadding(0, 12, 0, 12) })
  }
  scroll.addView(entries)
  root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
  setContentView(root)
 }
}
