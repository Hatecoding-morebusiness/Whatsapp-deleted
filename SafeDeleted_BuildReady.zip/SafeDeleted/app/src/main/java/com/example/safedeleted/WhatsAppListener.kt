package com.example.safedeleted

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WhatsAppListener : NotificationListenerService() {
 override fun onNotificationPosted(sbn: StatusBarNotification?) {
  if (sbn == null || sbn.packageName !in setOf("com.whatsapp", "com.whatsapp.w4b")) return
  val extras = sbn.notification.extras
  val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
  val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
   ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
   ?: return
  if (sender.isBlank() || text.isBlank() || text == "Checking for new messages") return
  // Avoid duplicate notification updates and retain only actual message text.
  val signature = "$sender\u0000$text"
  val prefs = getSharedPreferences("dedupe", MODE_PRIVATE)
  if (prefs.getString(sbn.key, null) == signature) return
  prefs.edit().putString(sbn.key, signature).apply()
  SecureStore.add(this, sender, text, System.currentTimeMillis())
 }
}
