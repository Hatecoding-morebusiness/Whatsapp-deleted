package com.example.safedeleted

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecureStore {
 private const val ALIAS = "safedeleted_aes_key"
 private fun key(): SecretKey {
  val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
  (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
  return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
   init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
    .setKeySize(256).build())
  }.generateKey()
 }
 @Synchronized fun read(context: Context): JSONArray {
  val encoded = context.getSharedPreferences("local", Context.MODE_PRIVATE).getString("messages", null) ?: return JSONArray()
  return try {
   val bytes = Base64.decode(encoded, Base64.NO_WRAP)
   val cipher = Cipher.getInstance("AES/GCM/NoPadding")
   cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
   JSONArray(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8))
  } catch (_: Exception) { JSONArray() }
 }
 @Synchronized fun add(context: Context, sender: String, message: String, timestamp: Long) {
  val array = read(context)
  array.put(JSONObject().put("sender", sender).put("message", message).put("time", timestamp))
  val bounded = JSONArray()
  for (i in maxOf(0, array.length() - 1000) until array.length()) bounded.put(array.get(i))
  write(context, bounded)
 }
 @Synchronized fun clear(context: Context) { context.getSharedPreferences("local", Context.MODE_PRIVATE).edit().remove("messages").apply() }
 private fun write(context: Context, array: JSONArray) {
  val cipher = Cipher.getInstance("AES/GCM/NoPadding")
  cipher.init(Cipher.ENCRYPT_MODE, key())
  val blob = cipher.iv + cipher.doFinal(array.toString().toByteArray(Charsets.UTF_8))
  context.getSharedPreferences("local", Context.MODE_PRIVATE).edit().putString("messages", Base64.encodeToString(blob, Base64.NO_WRAP)).commit()
 }
}
